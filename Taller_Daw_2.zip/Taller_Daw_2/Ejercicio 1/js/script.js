var movieDB = [
    {title: "Toy Story 4",
     rating: 4,
     runtime: 124,
     information: "Clasificacion: A || Formato de Película: 2D  Butacas: Tradicionales",
     synopsis: " Los juguetes se embarcarán en una aventura de la que no se olvidarán jamás junto con forky.",
     schedule:"Primer función: 2:00 pm || Segunda Función: 6:00 pm",
     background: "url('https://wallpaper.dog/large/20391094.jpg')"
    },
    {title: "The Incredibles 2",
     rating: 4.6,
     runtime: 92,
     information: "Clasificacion: A || Formato de Película: 2D, 3D Butacas: D-Box",
     synopsis: "Vuelve la familia con poderes, y con una nueva amenaza cibernetica y paternal?",
     schedule:"Primer función: 10:00 am || Segunda Función: 4:00 pm",
     background: "url('https://www.verdict.co.uk/wp-content/uploads/2018/07/incredibles-2-1200-1200-675-675-crop-000000.jpg')"
    },
    {title: "Spider-Man: Homecoming",
     rating: 4.8,
     runtime: 130,
     information: "Clasificacion: A || Formato de Película: 2D, 3D Butacas: Tradicionales",
     synopsis: "Ddespués de su aventura con los Vengadores. Al volver, descubre que ha surgido un nuevo y despiadado enemigo que pretende destruir todo lo que ama: el Buitre.",
     schedule:"Primer función: 11:00 am || Segunda Función: 2:00 pm",
     background: "url('https://images8.alphacoders.com/815/815755.jpg')"
    },
    {title: "The Avengers",
     rating: 4.2,
     runtime:  118,
     information: "Clasificacion: C || Formato de Película: 2D, 3D Butacas: Tradicionales",
     synopsis: "Los vengadores deberan enfrentarse al Dios nordico Loki y evitar una invasión",
     schedule: "Primer función: 7:00 am || Segunda Función: 10:00 am", 
     background: "url('https://images3.alphacoders.com/109/thumbbig-1098318.webp')",
    },
    {title: "Avatar The Way of Water",
     rating: 0,
     runtime:  162,
     information: "Clasificacion: A || Formato de Película: 2D, 3D Butacas: D-Box",
     synopsis: "Jake y Ney han formado una familia y hacen todo lo posible por permanecer juntos. Sin embargo, deben abandonar su hogar cuando una antigua amenaza reaparece.",
     schedule: "Proximamente", 
     background: "url('https://eloutput.com/app/uploads-eloutput.com/2021/12/avatar-2-cartel.jpg')",
    }
];

function printMovieInfo(element) {
if (element.hasWatched)
console.log("Ya la has visto " + element.title + " - " + element.rating + " stars");
else
console.log("Aun no la has visto " + element.title + " - " + element.rating + " stars");
}

// console stuff
movieDB.forEach(printMovieInfo);

movieDB.forEach(createCard);

function createCard(element, i){
// card
var card = document.createElement('div');
card.setAttribute("class", "movie-card");
card.style.backgroundImage = element.background;

// title
var title = document.createElement('h1');
title.innerText = element.title;
card.appendChild(title);

// runtime
var runtime = document.createElement('span');
runtime.innerText = element.runtime + " min";
card.appendChild(runtime);

// rating
var star = document.createElement("i");
star.setAttribute("class", "fas fa-star");
var rating = document.createElement('span');
rating.innerText = element.rating + " ";
rating.appendChild(star);
card.appendChild(rating);
// information
var information = document.createElement('p');
information.innerText = element.information;
card.appendChild(information);

// Sipnosis
var synopsis = document.createElement('p');
synopsis.innerText = element.synopsis;
card.appendChild(synopsis);

// Horarios
var schedule = document.createElement('h3');
schedule.innerText = element.schedule;
card.appendChild(schedule);

document.body.appendChild(card);
}